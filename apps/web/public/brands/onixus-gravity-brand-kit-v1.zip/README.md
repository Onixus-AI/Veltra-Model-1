# Onixus Gravity identity, v1

The Gravity symbol is the parent identity for Onixus. Workspace and Client Portal use the same symbol and wordmark with a descriptive label. Onyx remains an assistant, not the parent logo.

Use the transparent SVG master for interfaces and the PNG export for email, video and graphics. Choose the light lockup on pale backgrounds and the dark lockup on dark backgrounds. Preserve proportions and clear space of at least one core-circle radius. Do not stretch, add a glow, or substitute the former robot head.

Palette: purple #9945FF, magenta #FF2BD6, cyan #00C2FF. Existing Onixus interface colors remain unchanged. The wordmark is outlined geometry and does not depend on a font download.

Legacy Onixus image filenames are compatibility exports of the new Gravity symbol. Historical published media and third-party social-profile avatars are not rewritten by this asset release.
