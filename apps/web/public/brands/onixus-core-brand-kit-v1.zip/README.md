# Onixus Core — approved identity

Approved: three pillars (purple, magenta, cyan), true Onixus-green center, and the wide ONIXUS wordmark. Presentation background is jet black. Gravity and four-pillar concepts were rejected.

The approved full lockup is onixus-core-lockup-black-v1.png. onixus-core-v1.png is the matching emblem-only production export. Keep these raster masters unchanged: do not substitute a newly drawn symbol. The SVG mark embeds the approved raster and is not an outlined vector master.

Workspace and Client Portal use the same Core emblem with descriptive labels. Light/dark lockups adapt lettering contrast while preserving the black-backed emblem. Interface palette and page layouts remain unchanged.

Legacy Onixus image filenames are compatibility copies. Onyx assistant and customer logos remain separate. Already-published media and third-party social avatars are not rewritten by this asset release.
